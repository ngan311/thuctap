<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>i_Login</name>
   <tag></tag>
   <elementGuidId>93e9b4bc-4301-4609-b268-aeed8da108e7</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>.fa</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//*[@class and contains(concat(' ', normalize-space(@class), ' '), ' fa ')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=button[name=&quot; Login&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>i</value>
      <webElementGuid>5a4ea465-76d8-457b-9d82-e19ae99556af</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>fa fa-2x fa-sign-in</value>
      <webElementGuid>ac62591a-9d14-4528-adfd-03ff74f4f866</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value> Login</value>
      <webElementGuid>d98c480d-ec51-4441-8b37-0ed9a87ad046</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>parent</name>
      <type>Main</type>
      <value>md5.v1-243297f209e513dfe6dd28a1af11981c</value>
      <webElementGuid>faefd479-11a2-4716-b1ce-114d6eaf18e3</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[@class and contains(concat(' ', normalize-space(@class), ' '), ' fa ')]</value>
      <webElementGuid>6b486c78-09dd-4bcf-82a4-0f9c597b460e</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//*[@class and contains(concat(' ', normalize-space(@class), ' '), ' fa ')]</value>
      <webElementGuid>f56ffd03-9386-4fa5-9b30-7c831ad68a68</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//i[(text() = ' Login' or . = ' Login')]</value>
      <webElementGuid>7c58d38a-cc46-49fa-839e-a52b170bec38</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
