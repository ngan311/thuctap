<form method="POST">

    <input type="text" name="username" placeholder="Username" required>

    <input type="email" name="email" placeholder="Email" required>

    <input type="password" name="password" placeholder="Password" required>

    <button type="submit" name="register">
        Register
    </button>

</form>

<?php
include '../includes/db.php';

if(isset($_POST['register'])){

    $username = $_POST['username'];
    $email = $_POST['email'];

    $password = password_hash(
        $_POST['password'],
        PASSWORD_DEFAULT
    );
    $check = "SELECT * FROM users
          WHERE email='$email'";
          echo "Email đã tồn tại";

    $sql = "INSERT INTO users(username,email,password)
            VALUES('$username','$email','$password')";

    mysqli_query($conn, $sql);

    echo "Đăng ký thành công";
}
?>