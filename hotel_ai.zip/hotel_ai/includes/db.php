<?php

$conn = mysqli_connect(

    "localhost",

    "root",

    "123456",

    "hotel"
);

if(!$conn){

    die("Kết nối thất bại");
}

?>