<?php
include '../../includes/db.php';

$id = $_GET['id'];

$sql = "SELECT * FROM hotels WHERE id='$id'";
$result = mysqli_query($conn, $sql);
$row = mysqli_fetch_assoc($result);

if(isset($_POST['update'])){

    $hotel_name = $_POST['hotel_name'];
    $stars = $_POST['stars'];
    $final_price = $_POST['final_price'];
    $description = $_POST['description'];

    $sql = "UPDATE hotels SET

        hotel_name='$hotel_name',
        stars='$stars',
        final_price='$final_price',
        description='$description'

    WHERE id='$id'";

    mysqli_query($conn, $sql);

    header("Location: index.php");
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Hotel</title>
</head>
<body>

<h1>Edit Hotel</h1>

<form method="POST">

<input type="text"
       name="hotel_name"
       value="<?php echo $row['hotel_name']; ?>">

<br><br>

<input type="number"
       name="stars"
       value="<?php echo $row['stars']; ?>">

<br><br>

<input type="number"
       name="final_price"
       value="<?php echo $row['final_price']; ?>">

<br><br>

<textarea name="description">
<?php echo $row['description']; ?>
</textarea>

<br><br>

<button type="submit"
        name="update">

Update

</button>

</form>

</body>
</html>