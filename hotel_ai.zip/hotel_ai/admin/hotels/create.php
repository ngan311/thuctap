<?php
include '../../includes/admin_auth.php';
include '../../includes/db.php';

if(isset($_POST['save'])){
    $hotel_name = $_POST['hotel_name'];
    $room_type = $_POST['room_type'];
    $stars = $_POST['stars'];
    $location_area = $_POST['location_area'];
    $rating = $_POST['rating'];
    $base_price = $_POST['base_price'];
    $final_price = $_POST['final_price'];
    $description = $_POST['description'];
    $image = $_FILES['image']['name'];
    $tmp = $_FILES['image']['tmp_name'];
    $extension = pathinfo(
        $image,
        PATHINFO_EXTENSION
    );

    $allowed = [
        'jpg',
        'jpeg',
        'png'
    ];

    if(!in_array($extension, $allowed)){
        die("File không hợp lệ");
    }
    if($_FILES['image']['size']
       > 2000000){
        die("File quá lớn");
    }

    $image = time() . '_' . $image;
    move_uploaded_file(
        $tmp,
        '../../uploads/' . $image
    );

    $sql = "INSERT INTO hotels(
        hotel_name,
        room_type,
        stars,
        location_area,
        description,
        image,
        rating,
        base_price,
        final_price

    ) VALUES(
        '$hotel_name',
        '$room_type',
        '$stars',
        '$location_area',
        '$description',
        '$image',
        '$rating',
        '$base_price',
        '$final_price'
    )";
    mysqli_query($conn, $sql);
    header("Location: index.php");
}
?>


<!DOCTYPE html>
<html>
<head>
    <title>Create Hotel</title>
</head>
<body>
    <h1>Thêm khách sạn</h1>
    <form method="POST"
      enctype="multipart/form-data">
      <input type="text" name="hotel_name" placeholder="Tên khách sạn" required>
        <br>
            <br>
                <input type="text" name="room_type" placeholder="Loại phòng" required>
            <br>
        <br>
        <input type="number" name="stars" placeholder="Số sao" required>
        <br>
            <br>
            <input type="text" name="location_area" placeholder="Khu vực" required>
            <br>
        <br>
        <input type="number" step="0.1" name="rating" placeholder="Rating" required>
        <br>
            <br>
            <input type="number" name="base_price" placeholder="Giá gốc" required>
            <br>
        <br>
        <input type="number" name="final_price" placeholder="Giá hiện tại" required>
        <br>
            <br>
            <textarea name="description" placeholder="Mô tả" required>
            </textarea>
            <br>
            <br>
            <input type="file" name="image" required>
            <br>
            <br>
            <button type="submit" name="save"> Save </button>
    </form>
</body>
</html>