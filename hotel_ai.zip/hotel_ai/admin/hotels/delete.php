<?php
include '../../includes/admin_auth.php';
include '../../includes/db.php';

$id = $_GET['id'];

$sql = "DELETE FROM hotels WHERE id='$id'";

mysqli_query($conn, $sql);

header("Location: index.php");
?>