<?php
include '../../includes/admin_auth.php';
include '../../includes/db.php';

$id = $_GET['id'];

$sql = "SELECT * FROM hotels WHERE id='$id'";
$result = mysqli_query($conn, $sql);
$row = mysqli_fetch_assoc($result);
?>

<!DOCTYPE html>
<html>
<head>
    <title>View Hotel</title>
</head>
<body>

<h1><?php echo $row['hotel_name']; ?></h1>

<img src="../../uploads/<?php echo $row['image']; ?>"
     width="300">

<p>Stars: <?php echo $row['stars']; ?></p>

<p>Location:
<?php echo $row['location_area']; ?>
</p>

<p>Rating:
<?php echo $row['rating']; ?>
</p>

<p>Base Price:
<?php echo $row['base_price']; ?>
</p>

<p>Final Price:
<?php echo $row['final_price']; ?>
</p>

<p>Description:</p>

<p>
<?php echo $row['description']; ?>
</p>

</body>
</html>