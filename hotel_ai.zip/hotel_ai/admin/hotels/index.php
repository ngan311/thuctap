<?php

$sql = "SELECT * FROM hotels ORDER BY id DESC";
$result = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Hotels</title>
</head>
<body>

<h1>Danh sách khách sạn</h1>

<a href="create.php">Thêm khách sạn</a>

<br><br>

<table border="1" cellpadding="10">

<tr>
    <th>ID</th>
    <th>Image</th>
    <th>Name</th>
    <th>Stars</th>
    <th>Price</th>
    <th>Action</th>
</tr>

<?php while($row = mysqli_fetch_assoc($result)){ ?>

<tr>

<td><?php echo $row['id']; ?></td>

<td>
<img src="../../uploads/<?php echo $row['image']; ?>"
     width="100">
</td>

<td><?php echo $row['hotel_name']; ?></td>

<td><?php echo $row['stars']; ?></td>

<td><?php echo $row['final_price']; ?></td>

<td>

<a href="view.php?id=<?php echo $row['id']; ?>">
View
</a>

|

<a href="edit.php?id=<?php echo $row['id']; ?>">
Edit
</a>

|

<a href="delete.php?id=<?php echo $row['id']; ?>">
Delete
</a>

</td>

</tr>

<?php } ?>

</table>

</body>
</html>