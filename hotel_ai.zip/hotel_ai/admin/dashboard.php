<?php
include '../includes/admin_auth.php';
include '../includes/db.php';

$sql = "SELECT COUNT(*) as total FROM hotels";
$result = mysqli_query($conn, $sql);
$data = mysqli_fetch_assoc($result);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Dashboard</title>
</head>
<body>

<h1>Admin Dashboard</h1>

<h3>Tổng khách sạn:
<?php echo $data['total']; ?>
</h3>

<a href="hotels/index.php">
    Quản lý khách sạn
</a>

</body>
</html>