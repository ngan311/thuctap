<?php
include 'includes/db.php';
$search = "";
$min = 0;
$max = 999999999;
$stars = 0;

if(isset($_GET['search'])){
    $search = $_GET['search'];
}
if(isset($_GET['min_price'])
   && $_GET['min_price'] != ""){
    $min = $_GET['min_price'];
}
if(isset($_GET['max_price'])
   && $_GET['max_price'] != ""){
    $max = $_GET['max_price'];
}
if(isset($_GET['stars'])
   && $_GET['stars'] != ""){
    $stars = $_GET['stars'];
}

$sql = "SELECT * FROM hotels WHERE hotel_name LIKE '%$search%' AND final_price BETWEEN $min AND $max AND stars >= $stars ORDER BY id DESC";
$result = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html>
    <head>
        <title>Hotels</title>
    </head>
<body>
    <h1>Danh sách khách sạn</h1>
    <form method="GET">
    <input type="text" name="search" placeholder="Tìm khách sạn">
    <input type="number" name="min_price" placeholder="Giá thấp nhất">
    <input type="number" name="max_price" placeholder="Giá cao nhất">
        <select name="stars">
            <option value=""> Số sao </option>
            <option value="1"> 1 Sao </option>
            <option value="2"> 2 Sao </option>
            <option value="3"> 3 Sao </option>
            <option value="4"> 4 Sao </option>
            <option value="5"> 5 Sao </option>
        </select>
        <button type="submit"> Search </button>
    </form>
<hr>

<?php while($row =
mysqli_fetch_assoc($result)){ ?>
<div style="width:300px; border:1px solid #ccc; padding:10px; margin-bottom:20px; ">
<img src="uploads/<?php
echo $row['image']; ?>"
width="100%">
<h3>
    <?php
    echo $row['hotel_name']; ?>
</h3>
<p>
    Stars: <?php echo $row['stars']; ?>
</p>
<p>
    Price: <?php echo $row['final_price']; ?>
</p>
<p>
    Location: <?php echo $row['location_area']; ?>
</p>
<a href="hotel-detail.php?id= <?php echo $row['id']; ?>"> View Detail </a>
</div>
<?php } ?>
</body>
</html>